import React from 'react';

function Main(){
    return(
            <p>
            Hope you enjoy
            </p>
    )
}

export default Main;