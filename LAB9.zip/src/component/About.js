import React from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useState } from 'react';

function About () {
	return(
		<div>
			<Search/>
		</div>
	)
}

function Search() {
	const [message, setMessage] = useState('');
  	const [updated, setUpdated] = useState(message);

  	const handleChange = (event) => {
    	setMessage(event.target.value);
  	};

	const handleClick = () => {
		// "message" stores input field value
		setUpdated(message);
	};

  return (
    <div>
      <h2>Your search term : {updated}</h2>

      Search:<input
        type="text"
        id="message"
        name="message"
        onChange={handleChange}
        value={message}
      />

      {/* <h2>Message: {message}</h2> */}


      <button onClick={handleClick}>Submit</button>
    </div>
  );
}


export default About;
