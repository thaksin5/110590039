import './App.css';
import MySidebar from './component/Sidebar';
import React, { Component } from 'react';
import { BrowserRouter as Router,Routes, Route, Link } from 'react-router-dom';
import Album from './component/Album'

function App(){
  return(
    <div className='App'>
      <Album />
    </div>
  )
}

export default App;
