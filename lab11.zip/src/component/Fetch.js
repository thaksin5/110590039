import React from 'react';
import { database } from '../firebase'
import { ref, onValue } from "firebase/database";


function ListItem(props) {
    return <li>{props.post}</li>;
}

function Fetch() {
    const myPosts = ref(database, 'posts/');
    let newPosts = []

    onValue(myPosts, (snapshot) => {
        snapshot.forEach((childSnapshot) => {
            const key = childSnapshot.key;
            const post = childSnapshot.val().post;
            newPosts.push({ key, post })
        })
    });

    const listPosts = newPosts.map((value) =>
        <ListItem key={value.key.toString()} post={value.post} />
    );

    return (
        <ul>
            {listPosts}
        </ul>
    );

}

export default Fetch;