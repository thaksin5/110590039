
// For firebase
import React, { useEffect, useState } from 'react';
// For firebase
import {database} from '../firebase'
import {ref, push, child, update, onValue, DataSnapshot} from "firebase/database";
import Fetch from './Fetch';

function Post() {
    const [post, setPost] = useState();
    const [posts, setPosts] = useState([]);
    const handleChange = (e) => {
        const {name , value} = e.target;
        if (name == 'post') {
            setPost(value)
        }
    }
    
    // read
    useEffect(() => {
      onValue(ref(database), DataSnapshot => {
        const data = DataSnapshot.val();
        if(data !== null){
          Object.values(data).map(post => {
            setPosts(oldArr => [...oldArr, post]);
          });
        }
      });
    }, []);

    // submit
    const handleSubmit = (e) => {
      let obj = {
        post : post,
       }
  
       // Create a unique key for new posts
      const newPostKey = push(child(ref(database), 'posts')).key;
      const updates = {};
      updates['/posts/' + newPostKey] = obj;
      update(ref(database), updates);
      // To prevent the page from reloading; very useful for debugging
      e.preventDefault()
    };
    
    return (
      <div>
        <Fetch/>
        <h2>Submit your post!</h2>
        <form onSubmit={handleSubmit}>
          <label>
            Search:
            <input name="post" onChange={handleChange}/>
          </label>
            <input type="submit" value="Post!" />
       </form> 
       {/* display data in database */}
       {posts.map((post)=>(
        <>
          <h1>{post.post}</h1>
        </>
       ))}
      </div>
    );
  }
export default Post;