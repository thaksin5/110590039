import React from "react";

function Todo({todo}){
    return(
        <div>
            <h1>{todo.post}</h1>
        </div>
    )
}

export default Todo